package Link;


import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import app.CCLabeler;
import app.ImagesToProcessList;
import app.MeasuresList;
import ij.ImagePlus;
import javafx.application.Application;
import javafx.event.ActionEvent;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;

import javafx.scene.control.TreeItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import javafx.scene.layout.VBox;

import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.scene.control.Label;





public class Interface extends Application{
	
	
	

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		
	
        Application.launch(args);
       
    }

	 @Override
	 public void start(Stage stage) throws Exception {
		 
		 
		 
		 
		stage.setTitle("Bienvenue");		 
		BorderPane root1 = new BorderPane();
		Scene sc = new Scene (root1, 800, 500);		 
		stage.setScene(sc);
		
		
		HBox hbox = new HBox();
		hbox.setPadding(new Insets(10));
		hbox.setSpacing(5);
		
		
		//console
			TextArea ta = new TextArea();
			ta. setPrefHeight(100); 
			ta. setPrefWidth(800); 
			
		
		 
	    	ta.setEditable(false);
	        Console console = new Console(ta);
	        PrintStream ps = new PrintStream(console, true);
	        System.setOut(ps);
	        System.setErr(ps);
	        Scene app = new Scene(ta);
	        hbox.getChildren().addAll(ta);
	        
	        
	        for (char c : "Bienvenue dans notre projet".toCharArray()) {
	            console.write(c);
	        }
	        ps.close();
	        for (char c : "\nConnexion r�ussie � la base de donn�es".toCharArray()) {
	            try {
					console.write(c);
				} catch (IOException e) {
					e.printStackTrace();
				}
	        }
	        ps.close();
		
	
		//Tableau
       /* TreeTableView<Ouvrage> Tableau = new TreeTableView<Ouvrage>();

        	//Colonne Titre
        	TreeTableColumn<Ouvrage, String> Titre = new TreeTableColumn<Ouvrage, String>("Titre");

        	//Colonne Auteur
        	TreeTableColumn<Ouvrage, String> Auteur = new TreeTableColumn<Ouvrage, String>("Auteur");
        	
        	
        	//Colonne Nombre de mots
        	TreeTableColumn<Ouvrage, String> date = new TreeTableColumn<Ouvrage, String>("Date");
 
        	//Colonne Nombre de mots
        	TreeTableColumn<Ouvrage, String> tag = new TreeTableColumn<Ouvrage, String>("Tags");
        	
        	//Colonne Nombre de mots
        	TreeTableColumn<Ouvrage, String> NbPages = new TreeTableColumn<Ouvrage, String>("Nombre de Pages");
        //D�finit comment aller chercher la valeur des attributs dans la classe Ouvrage
        Titre.setCellValueFactory(new TreeItemPropertyValueFactory<Ouvrage, String>("titre"));
        Auteur.setCellValueFactory(new TreeItemPropertyValueFactory<Ouvrage, String>("auteur"));
        date.setCellValueFactory(new TreeItemPropertyValueFactory<Ouvrage, String>("date"));
        tag.setCellValueFactory(new TreeItemPropertyValueFactory<Ouvrage, String>("tag"));
        NbPages.setCellValueFactory(new TreeItemPropertyValueFactory<Ouvrage, String>("nbPage"));
        
        //Ajoute les colonne au Tableau
        Tableau.getColumns().addAll(Titre, Auteur,date,tag,NbPages);

        //Informations
        Ouvrage un = new Ouvrage("Le petit Prince", "Antoine de Saint Exuperry", "1943", null);
        Ouvrage deux = new Ouvrage("L'Avare", "Moli�re" , "1668", null);
        Ouvrage trois = new Ouvrage("Le Rouge et le Noir", "Stendhal" , "1830", null);
           

        //Root Item
        TreeItem<Ouvrage> Ouvr1 = new TreeItem<Ouvrage>(un);
        TreeItem<Ouvrage> Ouvr2 = new TreeItem<Ouvrage>(deux);
        TreeItem<Ouvrage> Ouvr3 = new TreeItem<Ouvrage>(trois);

        Ouvr1.getChildren().addAll(Ouvr2, Ouvr3);
        Tableau.setRoot(Ouvr1);
       */
       

       
		//Barre de droite 
		VBox vbox2 = new VBox();
		vbox2.setPadding(new Insets(10));
		vbox2.setSpacing(40);
		
			//Boutons pr�sents dans la barre
			Button btn_Ouvrir = new Button("Ouvrir");
			Button btn_Ajouter = new Button("Ajouter");
			Button btn_Supprimer = new Button("Supprimer");
			Button btn_Editer = new Button("Editer");
			Button btn_Galerie = new Button("BDD");
			
			
			vbox2.getChildren().addAll(btn_Ouvrir,btn_Ajouter, btn_Supprimer, btn_Editer, btn_Galerie);		
		
		//Positionnement des �l�ments
		root1.setTop(hbox);
		root1.setRight(vbox2);
	//	root1.setCenter(Tableau);
		stage.show();
		
		
		// permet d'ouvrir l'interface  Ajouter
		btn_Ajouter.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				AnchorPane root = new AnchorPane();

				TextField t2 = new TextField();
				TextField t3 = new TextField();
				TextField t4 = new TextField("YYYY-MM-DD");
				TextField t5 = new TextField("Ex : C:\\\\Desktop\\\\projet\\\\00000.jpg");
				TextField t6 = new TextField("Ex : C:\\\\Desktop\\\\projet");

				Label l2 = new Label("Titre");
				Label l3 = new Label("Auteur");
				Label l4 = new Label("Date");
				Label l5 = new Label("Image � analyser");
				Label l6 = new Label("Emplacement sortie");
			


				Button button4 = new Button("Ajouter l'ouvrage");
				

				// (Titre) Anchor to the Top + Left + Right
				AnchorPane.setTopAnchor(t2, 20.0);
				AnchorPane.setLeftAnchor(t2, 140.0);
				AnchorPane.setRightAnchor(t2, 260.0);

				AnchorPane.setTopAnchor(l2, 22.0);
				AnchorPane.setLeftAnchor(l2, 30.0);
				AnchorPane.setRightAnchor(l2, 320.0);

				// (Auteur) Anchor to the Top + Left + Right
				AnchorPane.setTopAnchor(t3, 50.0);
				AnchorPane.setLeftAnchor(t3, 140.0);
				AnchorPane.setRightAnchor(t3, 260.0);

				AnchorPane.setTopAnchor(l3, 52.0);
				AnchorPane.setLeftAnchor(l3, 30.0);
				AnchorPane.setRightAnchor(l3, 320.0);

				// (Date) Anchor to the Top + Left + Right
				AnchorPane.setTopAnchor(t4, 80.0);
				AnchorPane.setLeftAnchor(t4, 140.0);
				AnchorPane.setRightAnchor(t4, 260.0);

				AnchorPane.setTopAnchor(l4, 82.0);
				AnchorPane.setLeftAnchor(l4, 30.0);
				AnchorPane.setRightAnchor(l4, 320.0);
				
				// (Image) Anchor to the Top + Left + Right
				AnchorPane.setTopAnchor(t5, 110.0);
				AnchorPane.setLeftAnchor(t5, 140.0);
				AnchorPane.setRightAnchor(t5, 150.0);

				AnchorPane.setTopAnchor(l5, 112.0);
				AnchorPane.setLeftAnchor(l5, 30.0);
				AnchorPane.setRightAnchor(l5, 320.0);
				
				// (Emplacement) Anchor to the Top + Left + Right
				AnchorPane.setTopAnchor(t6, 140.0);
				AnchorPane.setLeftAnchor(t6, 140.0);
				AnchorPane.setRightAnchor(t6, 150.0);

				AnchorPane.setTopAnchor(l6, 142.0);
				AnchorPane.setLeftAnchor(l6, 30.0);
				AnchorPane.setRightAnchor(l6, 320.0);



				// (B4) Anchor to the four sides of AnchorPane
				AnchorPane.setTopAnchor(button4, 180.0);
				AnchorPane.setLeftAnchor(button4, 50.0);
				AnchorPane.setRightAnchor(button4, 50.0);
				AnchorPane.setBottomAnchor(button4, 45.0);

				// Add buttons to AnchorPane
				root.getChildren().addAll(t2, t3, t4,t5,t6, l2, l3, l4,l5,l6, button4);
				Scene secondScene = new Scene(root, 500, 400);

				// New window (Stage)
				Stage newWindow = new Stage();
				newWindow.setTitle("Interface d'Ajout");
				newWindow.setScene(secondScene);

				// Set position of second window, related to primary window.
				newWindow.setX(stage.getX() + 800);
				newWindow.setY(stage.getY() + 100);

				newWindow.show();
				
				button4.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event2) {
						String TITRE = t2.getText();
						String AUTEUR = t3.getText();
						String DATE = t4.getText();
						String image = t5.getText();
						String imagefinale = t6.getText();
						
						Ouvrage ouvrage = new Ouvrage(TITRE, AUTEUR, DATE, null);
						
						
						if (event2.getSource() == button4) {
							
						try {
							String url = "jdbc:mysql://localhost:3307/test";
							ConnectionBD connectionBD = new ConnectionBD(url, "root", "usbw");
							connectionBD.createOuvrage(ouvrage);
							
						//script du prof	
						ImagesToProcessList ipl = new ImagesToProcessList();
						ipl.addImageName(image);
						CCLabeler counter = new CCLabeler();
                        ImagePlus Plus = new ImagePlus(image);
                        
						for (Object o : ipl) {
                                    // traite l'image et compte les particules
                                    String imagename_to_process = (String) o;
                                    System.out.println(imagename_to_process);
                                    counter.process(imagename_to_process);

                                    // recupère les mesures de l'image traitée
                                    MeasuresList measure_list = counter.getMeasures();
                                    counter.generate_output(Plus, imagefinale, TITRE);
                                    
                                    for (char c : "\nScan effectu�".toCharArray()) {
            							try {
            								console.write(c);
            							} catch (IOException e) {
            								e.printStackTrace();
            							}
            						}
            						ps.close();

            					}

                                
								
							if (connectionBD.exist(ouvrage)) {
								Alert alert = new Alert(AlertType.INFORMATION);
								alert.setTitle("Ajout d'ouvrage");
								alert.setHeaderText(ouvrage.getTitre());
								alert.setContentText("L'ouvrage a bien �t� ajout� � la base de donn�e !");
								alert.show(); 
								
								
								
								
							}
							
						} catch (ClassNotFoundException e) {
							
							e.printStackTrace();
						} catch (SQLException e) {
						
							e.printStackTrace();
						}	
						}
						
			
					} 
					
				});

				for (char c : "\nOuverture de l'interface d'Ajouts".toCharArray()) {
					try {
						console.write(c);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				ps.close();

					}

				});
		
		
		
		//Permet d'ouvrir l'interface Supprimer
		btn_Supprimer.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				AnchorPane root = new AnchorPane();
			       
			       TextField t1 = new TextField();
			       TextField t2 = new TextField();
			       TextField t3 = new TextField();
			       TextField t4 = new TextField("YYYY-MM-DD");
			      
			       
			       String titre = t2.getText();
					String auteur = t3.getText();
					String date = t4.getText();
				
			       
			       Label l1 = new Label("Id");
			       Label l2 = new Label("Titre");
			       Label l3 = new Label("Auteur");
			       Label l4 = new Label("Date");
			    


			       Button button4 = new Button("Supprimer l'ouvrage");
			       

					button4.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event2) {
							String TITRE = t2.getText();
							String AUTEUR = t3.getText();
							String DATE = t4.getText();
							
							
							Ouvrage ouvrage = new Ouvrage(TITRE, AUTEUR, DATE, null);
							if (event2.getSource() == button4) {
								
							try {
								String url = "jdbc:mysql://localhost:3307/test";
								ConnectionBD connectionBD = new ConnectionBD(url, "root", "usbw");
								connectionBD.deleteOuvrage(ouvrage);

								Alert alert = new Alert(AlertType.INFORMATION);
								alert.setTitle("Suppression d'ouvrage");
								alert.setHeaderText(ouvrage.getTitre());
								alert.setContentText("L'ouvrage a bien �t� supprim� de la base de donn�e !");
								alert.show(); 
									
									for (char c : "\nSuppression r�ussie".toCharArray()) {
										try {
											console.write(c);
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									ps.close();
								
								
							} catch (ClassNotFoundException e) {
								
								e.printStackTrace();
							} catch (SQLException e) {
							
								e.printStackTrace();
							}	
							}
							
				
						} 
						
					});


					// (Titre) Anchor to the Top + Left + Right
					AnchorPane.setTopAnchor(t2, 50.0);
					AnchorPane.setLeftAnchor(t2, 140.0);
					AnchorPane.setRightAnchor(t2, 260.0);

					AnchorPane.setTopAnchor(l2, 52.0);
					AnchorPane.setLeftAnchor(l2, 30.0);
					AnchorPane.setRightAnchor(l2, 320.0);

					// (Auteur) Anchor to the Top + Left + Right
					AnchorPane.setTopAnchor(t3, 80.0);
					AnchorPane.setLeftAnchor(t3, 140.0);
					AnchorPane.setRightAnchor(t3, 260.0);

					AnchorPane.setTopAnchor(l3, 82.0);
					AnchorPane.setLeftAnchor(l3, 30.0);
					AnchorPane.setRightAnchor(l3, 320.0);

					// (Date) Anchor to the Top + Left + Right
					AnchorPane.setTopAnchor(t4, 110.0);
					AnchorPane.setLeftAnchor(t4, 140.0);
					AnchorPane.setRightAnchor(t4, 260.0);

					AnchorPane.setTopAnchor(l4, 112.0);
					AnchorPane.setLeftAnchor(l4, 30.0);
					AnchorPane.setRightAnchor(l4, 320.0);


			       // (B4) Anchor to the four sides of AnchorPane
					AnchorPane.setTopAnchor(button4, 180.0);
					AnchorPane.setLeftAnchor(button4, 50.0);
					AnchorPane.setRightAnchor(button4, 50.0);
					AnchorPane.setBottomAnchor(button4, 45.0);

			       // Add buttons to AnchorPane
			       root.getChildren().addAll(t2, t3, t4, l2, l3, l4, button4);
			       Scene secondScene = new Scene(root, 500, 400);
			   	
				// New window (Stage)
				Stage newWindow = new Stage();
				newWindow.setTitle("Interface de Suppression");
				newWindow.setScene(secondScene);

				// Set position of second window, related to primary window.
				newWindow.setX(stage.getX() + 800);
				newWindow.setY(stage.getY() + 100);

				newWindow.show();
				
				 for (char c : "\nOuverture de l'interface de Suppression".toCharArray()) {
			            try {
							console.write(c);
						} catch (IOException e) {
							e.printStackTrace();
						}
			        }
			        ps.close();
				
				
			}
		});
		/*		btn_Supprimer.setOnMouseClicked((event) -> {
				    try {
				        FXMLLoader fxmlLoader = new FXMLLoader();
				        fxmlLoader.setLocation(getClass().getResource("Supprimer.fxml"));
				       
				        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
				        Stage stage1 = new Stage();
				        stage1.setTitle("New Window");
				        stage1.setScene(scene);
				        stage1.show();
				    } catch (IOException e) {
				        Logger logger = Logger.getLogger(getClass().getName());
				        logger.log(Level.SEVERE, "Failed to create new Window.", e);
				    }
			 
				    
				}); */
		
			
				
				//Permet d'ouvrir l'interface Editer
				btn_Editer.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent event) {
						AnchorPane root = new AnchorPane();
					       
					       TextField t1 = new TextField();
					       TextField t2 = new TextField();
					       TextField t3 = new TextField();
					       TextField t4 = new TextField("YYYY-MM-DD");
					       
					       Label l1 = new Label("Id de l'ouvrage � �diter : ");
					       Label l2 = new Label("Titre");
					       Label l3 = new Label("Auteur");
					       Label l5 = new Label("Date");
					       
					       
					       Label l4 = new Label("Entrez les nouvelles caract�ristiques de l'ouvrage :");
					       
					     
					    	   

					       Button button4 = new Button("Editer l'ouvrage");

					       // (Id) Anchor to the Top + Left + Right
					       AnchorPane.setTopAnchor(t1, 20.0);
					       AnchorPane.setLeftAnchor(t1, 170.0);
					       AnchorPane.setRightAnchor(t1, 250.0);
					       
					       AnchorPane.setTopAnchor(l1, 22.0);
					       AnchorPane.setLeftAnchor(l1, 30.0);
					       AnchorPane.setRightAnchor(l1, 320.0);
					       
					       // (Titre) Anchor to the Top + Left + Right
					       AnchorPane.setTopAnchor(t2, 70.0);
					       AnchorPane.setLeftAnchor(t2, 50.0);
					       AnchorPane.setRightAnchor(t2, 320.0);
					       
					       AnchorPane.setTopAnchor(l2, 72.0);
					       AnchorPane.setLeftAnchor(l2, 20.0);
					       AnchorPane.setRightAnchor(l2, 320.0);
					       
					       // (Auteur) Anchor to the Top + Left + Right
					       AnchorPane.setTopAnchor(t3, 100.0);
					       AnchorPane.setLeftAnchor(t3, 50.0);
					       AnchorPane.setRightAnchor(t3, 320.0);
					       
					       AnchorPane.setTopAnchor(l3,102.0);
					       AnchorPane.setLeftAnchor(l3, 10.0);
					       AnchorPane.setRightAnchor(l3, 320.0);
					       
					    // (Date) Anchor to the Top + Left + Right
					       AnchorPane.setTopAnchor(t4, 85.0);
					       AnchorPane.setLeftAnchor(t4, 250.0);
					       AnchorPane.setRightAnchor(t4, 150.0);
					       
					       AnchorPane.setTopAnchor(l5,87.0);
					       AnchorPane.setLeftAnchor(l5, 210.0);
					       AnchorPane.setRightAnchor(l5, 150.0);
					       
					       // (phrase l4) Anchor to the Top + Left + Right
					       AnchorPane.setTopAnchor(l4, 52.0);
					       AnchorPane.setLeftAnchor(l4, 10.0);
					       AnchorPane.setRightAnchor(l4,0.0);

					       // (B4) Anchor to the four sides of AnchorPane
					       AnchorPane.setTopAnchor(button4, 150.0);
					       AnchorPane.setLeftAnchor(button4, 50.0);
					       AnchorPane.setRightAnchor(button4, 50.0);
					       AnchorPane.setBottomAnchor(button4, 45.0);

					       // Add buttons to AnchorPane
					       root.getChildren().addAll(t1, t2, t3,t4, l1,l2,l3,l4,l5, button4);
					       Scene secondScene = new Scene(root, 500, 300);
					   	
						// New window (Stage)
						Stage newWindow = new Stage();
						newWindow.setTitle("Interface d'Editage");
						newWindow.setScene(secondScene);

						// Set position of second window, related to primary window.
						newWindow.setX(stage.getX() + 800);
						newWindow.setY(stage.getY() + 100);

						newWindow.show();
						
						button4.setOnAction(new EventHandler<ActionEvent>() {
							@Override
							public void handle(ActionEvent event2) {
								String id = "'"+t1.getText()+"'";
								String TITRE = "'"+t2.getText()+"'";
								String AUTEUR = "'"+t3.getText()+"'";
								String DATE = "'"+t4.getText()+"'";



								
								
								if (event2.getSource() == button4) {
									
								try {
									String url = "jdbc:mysql://localhost:3307/test";
									ConnectionBD connectionBD = new ConnectionBD(url, "root", "usbw");
									Statement stmt = connectionBD.getConnection().createStatement();
									String sql = "UPDATE ouvrage SET Titre="+TITRE+"WHERE Id_Ouvrage="+id;
									int i = stmt.executeUpdate(sql);
									String sql2 = "UPDATE ouvrage SET Auteur="+AUTEUR+"WHERE Id_Ouvrage="+id;
									int i2 = stmt.executeUpdate(sql2);
									String sql3 = "UPDATE ouvrage SET DateDeParution="+DATE+"WHERE Id_Ouvrage="+id;
									int i3 = stmt.executeUpdate(sql3);
									
									for (char c : "\nUpdate r�ussie".toCharArray()) {
										try {
											console.write(c);
										} catch (IOException e) {
											e.printStackTrace();
										}
									}
									ps.close();
								

								} catch (ClassNotFoundException e) {
									
									e.printStackTrace();
								} catch (SQLException e) {
								
									e.printStackTrace();
								}	
								}
								
					
							} 
							
						});
						
						 for (char c : "\nOuverture de l'interface d'Editage".toCharArray()) {
					            try {
									console.write(c);
								} catch (IOException e) {
									e.printStackTrace();
								}
					        }
					        ps.close();
						
						
					}
					
				});
		
				//Permet d'ouvrir l'interface Ouvrir
				
				
				btn_Ouvrir.setOnAction(new EventHandler<ActionEvent>() {

					@Override
					public void handle(ActionEvent event) {

						Label Label = new Label(" Id � ouvrir :");
						Label Label2 = new Label("           ");
						
						BorderPane secondaryLayout = new BorderPane();
						TextField tf = new TextField();
						
						
						secondaryLayout.setLeft(Label);
						secondaryLayout.setRight(Label2);
						secondaryLayout.setCenter(tf);
						Scene secondScene = new Scene(secondaryLayout, 300, 100);

						// New window (Stage)
						Stage newWindow = new Stage();
						newWindow.setTitle("Interface d'Ouverture");
						newWindow.setScene(secondScene);

						// Set position of second window, related to primary window.
						newWindow.setX(stage.getX() + 800);
						newWindow.setY(stage.getY() + 100);

						newWindow.show();
						
						
						
						for (char c : "\nOuverture de l'interface d'Ouverture".toCharArray()) {
				            try {
								console.write(c);
							} catch (IOException e) {
								e.printStackTrace();
							}
				        }
				        ps.close();
					}
				});
			
			/*	btn_Ouvrir.setOnMouseClicked((event) -> {
				    try {
				        FXMLLoader fxmlLoader = new FXMLLoader();
				        fxmlLoader.setLocation(getClass().getResource("Ouvrir.fxml"));
				       
				        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
				        Stage stage1 = new Stage();
				        stage1.setTitle("New Window");
				        stage1.setScene(scene);
				        stage1.show();
				    } catch (IOException e) {
				        Logger logger = Logger.getLogger(getClass().getName());
				        logger.log(Level.SEVERE, "Failed to create new Window.", e);
				    }
			 
				    
				}); */
		
		
				//Permet d'ouvrir l'interface BDD
		        btn_Galerie.setOnMouseClicked((event) -> {
		            System.out.println("Debut du test ! \n");
		            String url = "jdbc:mysql://localhost:3307/test";
		            try {
		                ConnectionBD connectionBD = new ConnectionBD(url, "root", "usbw");
		            
		                Connection con = DriverManager.getConnection(url, "root", "usbw");
		                
		                String query = "SELECT * FROM ouvrage";
		              
		                Statement stm = con.createStatement();
		                ResultSet res = stm.executeQuery(query);
		              
		                String columns[] = {"Id", "Titre", "Auteur", "Date de Parution" };
		                String data[][] = new String[1000][4];
		              
		                int i = 0;
		                while (res.next()) {
		                  int id = res.getInt("Id_Ouvrage");
		                  String s=Integer.toString(id);
		                  String titre = res.getString("Titre");
		                  String auteur = res.getString("Auteur");
		                  String date = res.getString("DateDeParution");
		                  data[i][0] = s ;
		                  data[i][1] = titre ;
		                  data[i][2] = auteur;
		                  data[i][3] = date;
		                  i++;
		                }
		              
		                DefaultTableModel model = new DefaultTableModel(data, columns);
		                JTable table = new JTable(model);
		                table.setShowGrid(true);
		                table.setShowVerticalLines(true);
		                JScrollPane pane = new JScrollPane(table);
		                JFrame f = new JFrame("Remplir JTable a partir d'une BDD");
		                f.setLocation(600,400);
		                JPanel panel = new JPanel();
		                panel.add(pane);
		                f.add(panel);
		                f.setSize(500, 250);
		               
		                f.setVisible(true);
		            
		            
		            
		            } catch (ClassNotFoundException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            } catch (SQLException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		         

		            
		          
		          
		        });
	 
	 }
		//�crit dans le TextArea, � la mani�re d'une console
	 	public static class Console extends OutputStream {

	        private TextArea output;

	        public Console(TextArea ta) {
	            this.output = ta;
	        }

	        @Override
	        public void write(int i) throws IOException {
	            output.appendText(String.valueOf((char) i));
	        }
	    }
	 	
	 	
	 	   
}
	

	 




