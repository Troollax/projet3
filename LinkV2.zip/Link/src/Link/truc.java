package Link;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import app.CCLabeler;
import app.ImagesToProcessList;
import app.MeasuresList;
import ij.ImagePlus;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class truc {
	
	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		
      	System.out.println("Debut du test ! \n");
        String url = "jdbc:mysql://localhost:3307/test";
		ConnectionBD connectionBD = new ConnectionBD(url, "root", "usbw");
     

        Connection con = DriverManager.getConnection(url, "root", "usbw");
        
        String query = "SELECT * FROM ouvrage";
      
        Statement stm = con.createStatement();
        ResultSet res = stm.executeQuery(query);
      
        String columns[] = { "ID", "Nom", "Age" };
        String data[][] = new String[8][3];
      
        int i = 0;
        while (res.next()) {
          String titre = res.getString("Titre");
          String auteur = res.getString("Auteur");
          String date = res.getString("DateDeParution");
          data[i][0] = titre ;
          data[i][1] = auteur;
          data[i][2] = date;
          i++;
        }
      
        DefaultTableModel model = new DefaultTableModel(data, columns);
        JTable table = new JTable(model);
        table.setShowGrid(true);
        table.setShowVerticalLines(true);
        JScrollPane pane = new JScrollPane(table);
        JFrame f = new JFrame("Remplir JTable a partir d'une BDD");
        JPanel panel = new JPanel();
        panel.add(pane);
        f.add(panel);
        f.setSize(500, 250);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
      
      } 
}	 
	 

    

